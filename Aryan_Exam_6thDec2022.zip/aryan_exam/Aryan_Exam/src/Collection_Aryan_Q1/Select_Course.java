package Collection_Aryan_Q1;

import java.util.Comparator;

class Select_Course implements Comparator<String>{
    @Override
   public int compare(String str1, String str2) {
       return str1.compareTo(str2);
   }
   
}

