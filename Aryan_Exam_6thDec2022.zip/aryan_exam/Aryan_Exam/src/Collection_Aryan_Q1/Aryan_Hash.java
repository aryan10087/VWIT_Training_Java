package Collection_Aryan_Q1;




import java.util.*;

public class Aryan_Hash {


	public static HashMap<String, String>
	sortByValue(HashMap<String, String> hm)
	{
		
		List<Map.Entry<String, String> > list
			= new LinkedList<Map.Entry<String, String> >(
				hm.entrySet());

		
		Collections.sort(
			list,
			new Comparator<Map.Entry<String, String> >() {
				public int compare(
					Map.Entry<String, String> object1,
					Map.Entry<String, String> object2)
				{
					return (object1.getValue())
						.compareTo(object2.getValue());
				}
			});

		
		HashMap<String, String> result
			= new LinkedHashMap<String, String>();
		for (Map.Entry<String, String> me : list) {
			result.put(me.getKey(), me.getValue());
		}


		return result;
	}

	
	public static void main(String[] args)
	{
		
		HashMap<String, String> hashmap
			= new HashMap<String, String>();

		
		hashmap.put("Aryan", "22 years");
		hashmap.put("Bharat", "21 years");
		hashmap.put("Sachin", "20 years");
		

		
		Map<String, String> map = sortByValue(hashmap);

		
		for (Map.Entry<String, String> entry :
			map.entrySet()) {
			System.out.println("Key : " + entry.getKey()
							+ ", Value : "
							+ entry.getValue());
		}
	}
}
