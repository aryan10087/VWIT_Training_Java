package Collection_Aryan_Q1;


import java.util.*;


public class Student_Aryan_Tree {  
    public static void main(String args[]){  
  TreeMap<String,String> tree_map1 = new TreeMap<String,String>(new Select_Course());
  
  tree_map1.put("Aryan", "Science");
  tree_map1.put("Bharat", "Commerce");
  tree_map1.put("Sachin", "Arts"); 
  System.out.println(tree_map1); 
    }
}