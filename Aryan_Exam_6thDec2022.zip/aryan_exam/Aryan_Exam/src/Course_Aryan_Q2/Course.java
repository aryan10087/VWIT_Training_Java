package Course_Aryan_Q2;

public class Course {


		String c_specialization;String c_duration;
		
	Course(){
		System.out.println("This is default course constructor...");
	}
	Course(String n, String d){
		c_specialization=n;
		c_duration=d;
	}
	
	static int calculateDuration(String name, int hours) {
		return 24*hours;
		
	}
	static int calculateDuration(String name, int hours,int weekdays) {
		return 20*hours;
		
	}
	public static void main(String[] args) {
		Course c= new Course();
		System.out.println("\n Default constructor values");
		System.out.println("Course Specialization: "+c.c_specialization+"\n Course duration"+c.c_duration);
		
		System.out.println("\n Parameterised constructor values");
		Course c1= new Course("CAT","1 year");
		System.out.println("Specialization: "+c1.c_specialization+"\nCourse duration: "+c1.c_duration);
		
		System.out.println("\n");
		System.out.println(calculateDuration("UPSC",14)+" hours");
		
		System.out.println(calculateDuration("CAT",8,5)+" hours");
		
		System.out.println("\n");
		
		Course c3=null;
		System.out.println(c3 instanceof Course);
		
	}
	
	
}

